/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jatoo.mp3;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class represents a MP3 player providing specific methods like
 * {@link #play()}, {@link #pause()}, {@link #stop()}, and so on.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.0, June 12, 2014
 */
public abstract class Mp3Player {

  /** The logger. */
  private transient final Log logger = LogFactory.getLog(getClass());

  /** The lock object. */
  private transient final Object lock = new Object();

  private Mp3PlayerStatus status = Mp3PlayerStatus.STOPPED;
  private int volume = Mp3.DEFAULT_VOLUME;

  /**
   * See {@link Mp3#play()} method.
   */
  public final void play() {
    synchronized (lock) {
      playImpl(lock);
    }
  }

  protected abstract void playImpl(Object lock);

  /**
   * See {@link Mp3#join()} method.
   */
  public abstract void join();

  /**
   * See {@link Mp3#isPlaying()} method.
   */
  public final boolean isPlaying() {
    synchronized (lock) {
      return status == Mp3PlayerStatus.PLAYING;
    }
  }

  /**
   * See {@link Mp3#pause()} method.
   */
  public final void pause() {

    logger.info("pause");

    synchronized (lock) {
      status = Mp3PlayerStatus.PAUSED;
    }
  }

  /**
   * See {@link Mp3#isPaused()} method.
   */
  public final boolean isPaused() {
    synchronized (lock) {
      return status == Mp3PlayerStatus.PAUSED;
    }
  }

  /**
   * See {@link Mp3#stop()} method.
   */
  public final void stop() {

    logger.info("stop");

    synchronized (lock) {
      status = Mp3PlayerStatus.STOPPED;
    }
  }

  /**
   * See {@link Mp3#isStopped()} method.
   */
  public final boolean isStopped() {
    synchronized (lock) {
      return status == Mp3PlayerStatus.STOPPED;
    }
  }

  /**
   * See {@link Mp3#setVolume(int)} method.
   */
  public final void setVolume(final int volume) throws IllegalArgumentException {

    if (volume < 0 || volume > 2 * Mp3.DEFAULT_VOLUME) {
      throw new IllegalArgumentException("Wrong value for volume (" + volume + "), must be in interval [0.." + (2 * Mp3.DEFAULT_VOLUME) + "].");
    }

    logger.info("volume: " + volume);

    this.volume = volume;
  }

  /**
   * See {@link Mp3#getVolume()} method.
   */
  public final int getVolume() {
    return volume;
  }

  /**
   * See {@link Mp3#getPosition()} method.
   */
  public abstract long getPosition();

  protected final void setStatus(final Mp3PlayerStatus status) {
    this.status = status;
  }

  protected final Mp3PlayerStatus getStatus() {
    return status;
  }
}
