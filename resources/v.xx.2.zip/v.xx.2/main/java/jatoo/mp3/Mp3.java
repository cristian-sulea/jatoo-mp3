/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jatoo.mp3;

import jatoo.mp3.impl.Mp3PlayerJavaZOOM;

import java.io.File;
import java.net.URL;

import javax.sound.sampled.SourceDataLine;

/**
 * This class represents a MP3 and provides ways to work with.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.0, June 12, 2014
 */
public final class Mp3 {

  /**
   * The value representing the volume when gain control is not changed or is
   * set to default value.
   */
  public static final int DEFAULT_VOLUME = 100;

  /** The MP3 player. */
  private transient final Mp3Player player;

  /** The MP3 tag manager. */
  // private Mp3TagManager tagManager;

  /**
   * Constructs a new {@link Mp3} object that represents the specified
   * {@link File} source.
   * 
   * @param file
   *          the source
   */
  public Mp3(final File file) {
    player = new Mp3PlayerJavaZOOM(new Mp3SourceFile(file));
  }

  /**
   * Constructs a new {@link Mp3} object that represents the specified
   * {@link String} source.
   * 
   * @param file
   *          the source
   */
  public Mp3(final String file) {
    player = new Mp3PlayerJavaZOOM(new Mp3SourceFile(file));
  }

  /**
   * Constructs a new {@link Mp3} object that represents the specified
   * {@link URL} source.
   * 
   * @param url
   *          the source
   */
  public Mp3(final URL url) {
    player = new Mp3PlayerJavaZOOM(new Mp3SourceURL(url));
  }

  /**
   * Starts to play this {@link Mp3} (or resume if is paused).
   */
  public void play() {
    player.play();
  }

  /**
   * Waits for the playing thread to finish.
   * 
   * @see Thread#join()
   */
  public void join() {
    player.join();
  }

  /**
   * Tests if this {@link Mp3} is playing.
   * 
   * @return <code>true</code> if this {@link Mp3} is playing,
   *         <code>false</code> otherwise
   */
  public boolean isPlaying() {
    return player.isPlaying();
  }

  /**
   * Pauses the play.
   */
  public void pause() {
    player.pause();
  }

  /**
   * Tests if this {@link Mp3} is paused.
   * 
   * @return <code>true</code> if this {@link Mp3} is paused, <code>false</code>
   *         otherwise
   */
  public boolean isPaused() {
    return player.isPaused();
  }

  /**
   * Stops the play.
   */
  public void stop() {
    player.stop();
  }

  /**
   * Tests if this {@link Mp3} is stopped.
   * 
   * @return <code>true</code> if this {@link Mp3} is stopped,
   *         <code>false</code> otherwise
   */
  public boolean isStopped() {
    return player.isStopped();
  }

  /**
   * Sets a new volume for this {@link Mp3}. The value is actually the percent
   * value, so the value must be in interval [0, {@value #DEFAULT_VOLUME}].
   * 
   * @param volume
   *          the new volume
   * 
   * @throws IllegalArgumentException
   *           if the volume is not in interval [0, {@value #DEFAULT_VOLUME}]
   */
  public void setVolume(final int volume) throws IllegalArgumentException {
    player.setVolume(volume);
  }

  /**
   * Returns the actual volume of this {@link Mp3}.
   * 
   * @return the volume
   */
  public int getVolume() {
    return player.getVolume();
  }

  /**
   * Retrieves the position in milliseconds of the current audio sample being
   * played. This method delegates to the {@link SourceDataLine} that is used by
   * this player to sound the decoded audio samples.
   * 
   * @return the position in milliseconds
   */
  public long getPosition() {
    return player.getPosition();
  }

}
