/*
 * Copyright (C) Cristian Sulea ( http://cristian.sulea.net )
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package jatoo.mp3.impl;

import jatoo.mp3.Mp3;
import jatoo.mp3.Mp3Player;
import jatoo.mp3.Mp3PlayerStatus;
import jatoo.mp3.Mp3Source;

import java.io.IOException;
import java.io.InputStream;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.BooleanControl;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.Line;
import javax.sound.sampled.SourceDataLine;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Default implementation for {@link Mp3Player} using JavaZOOM.
 * 
 * @author <a href="http://cristian.sulea.net" rel="author">Cristian Sulea</a>
 * @version 1.0, June 12, 2014
 */
public final class Mp3PlayerJavaZOOM extends Mp3Player {

  /** Number of microseconds in a millisecond (used by {@link #getPosition()}). */
  private static final long MICROSECONDS_IN_MILLISECOND = 1000L;

  private final Log logger = LogFactory.getLog(getClass());

  private volatile Mp3Source mp3Source;

  private volatile Thread thread;

  private volatile SourceDataLine sourceDataLine;

  private int sourceVolume = Mp3.DEFAULT_VOLUME;
  private float[] sourceVolumes = new float[2 * Mp3.DEFAULT_VOLUME + 1];

  public Mp3PlayerJavaZOOM(final Mp3Source mp3Source) {
    this.mp3Source = mp3Source;
  }

  @Override
  protected void playImpl(final Object lock) {

    //
    // if paused, play will unpause

    if (getStatus() == Mp3PlayerStatus.PAUSED) {

      logger.info("unpause");

      //
      // change the status to playing

      setStatus(Mp3PlayerStatus.PLAYING);

      //
      // wake up the playing thread

      lock.notifyAll();

      //
      // and that's all

      return;
    }

    //
    // if playing, play will first stop then play

    if (getStatus() == Mp3PlayerStatus.PLAYING) {

      logger.info("stop (forced stop before new play)");

      //
      // change the status to stopped

      setStatus(Mp3PlayerStatus.STOPPED);

      //
      // do this on a new thread, or we will lock everything

      new Thread() {
        public void run() {

          //
          // wait for the playing thread to finish

          try {
            thread.join();
          } catch (NullPointerException | InterruptedException e) {
            logger.error("Hmm... The method Thread#join() failed?", e);
          }

          //
          // launch a new play command

          play();
        }
      }.start();

      //
      // and that's all

      return;
    }

    //
    // it's a normal play command

    logger.info("play");

    //
    // if playing thread is not null, then the mp3 is already playing

    if (thread == null) {

      //
      // change the status to playing

      setStatus(Mp3PlayerStatus.PLAYING);

      //
      // create and launch the playing thread

      thread = new Thread() {
        public void run() {

          InputStream inputStream = null;
          Bitstream soundStream = null;

          try {

            inputStream = mp3Source.openStream();
            soundStream = new Bitstream(inputStream);

            Decoder decoder = new Decoder();

            //
            // start the cycle
            // will end on stop command or on end of stream

            while (true) {

              synchronized (lock) {

                //
                // if is a stop command
                // break the play

                if (getStatus() == Mp3PlayerStatus.STOPPED) {
                  break;
                }

                //
                // if is a pause command

                if (getStatus() == Mp3PlayerStatus.PAUSED) {

                  //
                  // flush the audio data

                  if (sourceDataLine != null) {
                    sourceDataLine.flush();
                  }

                  //
                  // and put the playing thread in wait for unpause

                  // TODO: daca se da stop dupa pauza, nu ramen in wait forever?

                  while (getStatus() == Mp3PlayerStatus.PAUSED) {
                    try {
                      lock.wait();
                    } catch (InterruptedException e) {
                      logger.error("The thread WAIT method failed, this means PAUSE will not work.", e);
                    }
                  }
                }
              }

              //
              // play

              try {

                //
                // read the stream frame by frame

                Header frame = soundStream.readFrame();

                //
                // if frame is null, the end of the stream has been reached

                if (frame == null) {
                  break;
                }

                else {

                  //
                  // first time / first frame
                  // create the playing source if is needed

                  if (sourceDataLine == null) {

                    int frequency = frame.frequency();
                    int channels = (frame.mode() == Header.SINGLE_CHANNEL) ? 1 : 2;

                    AudioFormat format = new AudioFormat(frequency, 16, channels, true, false);
                    Line line = AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, format));

                    sourceDataLine = (SourceDataLine) line;
                    sourceDataLine.open(format);
                    sourceDataLine.start();

                    //
                    // compute the source volumes

                    try {

                      FloatControl gainControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);

                      float stepMinimum = Math.abs(gainControl.getMinimum() / Mp3.DEFAULT_VOLUME);
                      float stepMaximum = gainControl.getMaximum() / Mp3.DEFAULT_VOLUME;

                      sourceVolumes[0] = gainControl.getMinimum();
                      sourceVolumes[Mp3.DEFAULT_VOLUME] = 0;
                      sourceVolumes[2 * Mp3.DEFAULT_VOLUME] = gainControl.getMaximum();

                      for (int i = 1, n = Mp3.DEFAULT_VOLUME - 1; i <= n; i++) {
                        sourceVolumes[i] = sourceVolumes[i - 1] + stepMinimum;
                      }

                      for (int i = Mp3.DEFAULT_VOLUME + 1, n = 2 * Mp3.DEFAULT_VOLUME; i <= n; i++) {
                        sourceVolumes[i] = sourceVolumes[i - 1] + stepMaximum;
                      }
                    }

                    catch (Throwable t) {

                      logger.error("Unexpected error calculating the source volumes.", t);

                      //
                      // in case of any error, set the source volume to 0
                      // meaning the signal's loudness is unaffected

                      for (int i = 0, n = 2 * Mp3.DEFAULT_VOLUME; i <= n; i++) {
                        sourceVolumes[i] = 0;
                      }
                    }
                  }

                  //
                  // update the volume on the source

                  if (sourceVolume != getVolume()) {

                    sourceVolume = getVolume();

                    FloatControl gainControl = (FloatControl) sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
                    BooleanControl muteControl = (BooleanControl) sourceDataLine.getControl(BooleanControl.Type.MUTE);

                    if (sourceVolume == 0) {
                      muteControl.setValue(true);
                    } else {
                      muteControl.setValue(false);
                      gainControl.setValue(sourceVolumes[sourceVolume]);
                    }
                  }

                  //
                  // play the frame

                  SampleBuffer output = (SampleBuffer) decoder.decodeFrame(frame, soundStream);

                  short[] buffer = output.getBuffer();
                  int offs = 0;
                  int len = output.getBufferLength();

                  sourceDataLine.write(toByteArray(buffer, offs, len), 0, len * 2);

                  //
                  // don't forget to close the frame

                  soundStream.closeFrame();
                }
              }

              catch (Exception e) {
                logger.error("Unexpected problems while playing.", e);
                break;
              }
            }
          }

          catch (IOException e) {
            logger.error("Unable to get the stream from input: " + mp3Source.toString(), e);
          }

          finally {

            if (sourceDataLine != null) {
              try {
                sourceDataLine.flush();
              } catch (Exception e) {
                logger.error("Error flushing the playing source.", e);
              }
              try {
                sourceDataLine.stop();
              } catch (Exception e) {
                logger.error("Error stopping the playing source.", e);
              }
              try {
                sourceDataLine.close();
              } catch (Exception e) {
                logger.error("Error closing the playing source.", e);
              }
            }

            if (soundStream != null) {
              try {
                soundStream.close();
              } catch (Exception e) {
                logger.error("Error closing the sound stream.", e);
              }
            }

            if (inputStream != null) {
              try {
                inputStream.close();
              } catch (Exception e) {
                logger.error("Error closing the input stream.", e);
              }
            }
          }

          //
          // end of run() method, so thread will die after this
          // don't forget to update status
          // and to reset thread and source

          setStatus(Mp3PlayerStatus.STOPPED);

          thread = null;
          sourceDataLine = null;
        }
      };

      thread.start();
    }
  }

  @Override
  public void join() {
    try {
      thread.join();
    } catch (InterruptedException e) {
      logger.error("failed to #join()", e);
    }
  }

  @Override
  public long getPosition() {
    if (sourceDataLine != null) {
      return sourceDataLine.getMicrosecondPosition() / MICROSECONDS_IN_MILLISECOND;
    } else {
      return 0L;
    }
  }

  private byte[] toByteArray(final short[] ss, final int offs, final int len) {

    int index = offs;
    int size = len;

    byte[] bb = new byte[size * 2];

    int idx = 0;
    short s;

    while (size-- > 0) {

      s = ss[index++];

      bb[idx++] = (byte) s;
      bb[idx++] = (byte) (s >>> 8);
    }

    return bb;
  }

}
